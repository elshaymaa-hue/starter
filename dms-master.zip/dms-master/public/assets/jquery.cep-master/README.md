#jQuery CEP Plugin
Um plugin jQuery para pegar endereços de acordo com o CEP informado.

## [VER DEMO](http://giovanneafonso.github.io/jquery.cep/)

**Este plugin ainda está em desenvolvimento. Você pode contribuir, se quiser.**

##Compatibilidade
jQuery CEP Plugin foi testado em jQuery 1.7+ em todos os principais navegadores:

  * Firefox 2+ (Win, Mac, Linux);
  * IE7+ (Win);
  * Chrome 6+ (Win, Mac, Linux, Android, iPhone);
  * Safari 3.2+ (Win, Mac, iPhone);
  * Opera 8+ (Win, Mac, Linux, Android, iPhone).

